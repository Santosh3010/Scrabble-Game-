# CEG-4120-Scrabble
This is the final working version of the CEG 4120 Group 9 Scrabble Game. 

There are two zipped folders in this repository. 

Scrabble.zip is the project file developed in Eclipse. If you wish to see all code, classes, and other elements of the project's implementation please download this file and unzip it to see its contents. 

Scrabble-Jar-File.zip is a folder containing the Scrabble.jar file and the dictionary.txt file. If you wish to just play the game, download and unzip this file. Using your command line application, navigate the directory that this folder has been unzipped in and execute the command: "java -jar Scrabble.jar dictionary.txt". This command will allow you to play the game. 
